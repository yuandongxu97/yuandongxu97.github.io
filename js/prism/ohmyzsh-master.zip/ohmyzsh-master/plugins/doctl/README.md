# Doctl

This plugin provides completion for [Doctl](https://github.com/digitalocean/doctl).

To use it add doctl to the plugins array in your zshrc file.

```bash
plugins=(... doctl)
```
